﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "JKFrame/LocalizationConfig")]
public class LocalizationConfig : LocalizationConfigBase<LanguageType>
{

}
