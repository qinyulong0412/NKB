﻿using UnityEngine;
namespace JKFrame
{
    public class EnumFlags : PropertyAttribute { }
}
